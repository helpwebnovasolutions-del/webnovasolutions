import { AIPlannerSection, BrandPromiseSection } from './components/AIPlannerSection.tsx';
import React, { useEffect, useState } from 'react';
import { Navbar } from './components/Navbar.tsx';
import { Hero } from './components/Hero.tsx';
import { WhyWebNovaAndAI } from './components/WhyWebNovaAndAI.tsx';
import { AICommandCenter } from './components/AICommandCenter.tsx';
import { ConnectedEcosystem } from './components/ConnectedEcosystem.tsx';
import { ExperienceLab } from './components/ExperienceLab.tsx';
import { AssociateEcosystem } from './components/AssociateEcosystem.tsx';
import { ValueProps } from './components/ValueProps.tsx';
import { AboutWebNova } from './components/AboutWebNova.tsx';
import { ServicesSection } from './components/ServicesSection.tsx';
import { SEOContentSection } from './components/SEOContentSection.tsx';
import { ProcessSection } from './components/ProcessSection.tsx';
import { FaqSection } from './components/FaqSection.tsx';
import { TestimonialsSection } from './components/TestimonialsSection.tsx';
import { ContactSection } from './components/ContactSection.tsx';
import { Footer } from './components/Footer.tsx';
import { UserPortalModal } from './components/UserPortalModal.tsx';
import { SupportHub } from './components/SupportHub.tsx';
import { ScheduleCall } from './components/ScheduleCall.tsx';
import { BlogSection } from './components/BlogSection.tsx';
import { CertificateVerificationPage } from './components/DocumentsAdminPanel.tsx';
import { FormSecurityAndCapture } from './components/FormSecurityAndCapture.tsx';
import { FirebaseAuthRoute } from './components/FirebaseAuthRoute.tsx';
import { ServiceRequestPrompt } from './components/ServiceRequestPrompt.tsx';
import { FreelancerComingSoon } from './components/FreelancerComingSoon.tsx';
import { GoogleReviewsSection } from './components/GoogleReviewsSection.tsx';
import { LegalPage } from './components/LegalPage.tsx';

function NotFoundPage() {
  return (
    <main className="min-h-screen flex items-center justify-center px-6 py-16 bg-[#f8faff] text-[#071531] relative overflow-hidden">
      <div className="absolute -top-24 -right-16 w-80 h-80 rounded-full bg-violet-300/30 blur-3xl" />
      <div className="absolute -bottom-24 -left-16 w-80 h-80 rounded-full bg-cyan-300/30 blur-3xl" />
      <div className="relative z-10 max-w-xl text-center">
        <img src="/webnova-logo.png" alt="WebNova Solutions" className="w-44 mx-auto mb-8" />
        <p className="text-sm font-bold tracking-[0.28em] uppercase text-blue-600 mb-3">Error 404</p>
        <h1 className="text-4xl sm:text-6xl font-extrabold tracking-tight mb-4">This page went digital… somewhere else.</h1>
        <p className="text-slate-600 leading-relaxed mb-8">The page you’re looking for may have moved, been renamed, or no longer exists.</p>
        <a href="/" className="inline-flex items-center justify-center rounded-xl px-6 py-3 text-white font-semibold bg-gradient-to-r from-blue-600 to-violet-600 shadow-lg shadow-blue-600/20 hover:-translate-y-0.5 transition-transform">Back to WebNova Home</a>
        <p className="text-xs text-slate-500 mt-8">WebNova Solutions · We build websites that grow businesses.</p>
      </div>
    </main>
  );
}

function BlogPage() {
  useEffect(() => {
    document.title = 'WebNova Insights Blog | Web Development, AI & Digital Growth';
    const description = 'Explore practical guides on website development, AI automation, SEO, digital marketing, and UI/UX design from WebNova Solutions.';
    let meta = document.querySelector<HTMLMetaElement>('meta[name="description"]');
    if (!meta) { meta = document.createElement('meta'); meta.name = 'description'; document.head.appendChild(meta); }
    meta.content = description;
    let canonical = document.querySelector<HTMLLinkElement>('link[rel="canonical"]');
    if (!canonical) { canonical = document.createElement('link'); canonical.rel = 'canonical'; document.head.appendChild(canonical); }
    canonical.href = 'https://webnovasolutions.co.in/blog';
  }, []);
  return <div className="min-h-screen bg-white text-slate-900">
    <header className="sticky top-0 z-40 border-b border-slate-100 bg-white/95 backdrop-blur-xl">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3 sm:px-6">
        <a href="/" aria-label="WebNova home"><img src="/webnova-logo.png" alt="WebNova Solutions" className="h-10 w-auto object-contain" /></a>
        <nav className="flex items-center gap-4 text-sm font-semibold sm:gap-7"><a href="/" className="text-slate-600 hover:text-blue-700">Home</a><a href="/blog" className="text-blue-700">Blog</a><a href="/#services" className="text-slate-600 hover:text-blue-700">Services</a><a href="/#contact" className="rounded-full bg-gradient-to-r from-blue-600 to-violet-600 px-4 py-2 text-white">Contact</a></nav>
      </div>
    </header>
    <BlogSection />
    <footer className="border-t border-slate-100 px-4 py-6 text-center text-xs text-slate-500">© WebNova Solutions · <a className="text-blue-700" href="/verify-certificate">Verify an intern certificate</a> · <a className="text-blue-700" href="/">Back to home</a></footer>
  </div>;
}

function HomePage() {
  const [userPhone, setUserPhone] = useState<string | null>(null);
  const [isPortalOpen, setIsPortalOpen] = useState(false);

  const handleLoginClick = () => {
    window.location.assign('/portal');
  };

  const handleLoginSuccess = (phone: string) => {
    setUserPhone(phone);
    setIsPortalOpen(true);
  };

  const handleLogout = () => {
    setUserPhone(null);
    setIsPortalOpen(false);
  };

  const handleStartProject = () => {
    const quoteElement = document.getElementById('quotation');
    if (quoteElement) {
      quoteElement.scrollIntoView({ behavior: 'smooth' });
    } else {
      const contact = document.getElementById('contact');
      contact?.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleExploreWork = () => {
    const services = document.getElementById('services');
    services?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleExploreAITools = () => {
    const aiSection = document.getElementById('ai-command');
    aiSection?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-white text-slate-800 selection:bg-blue-600 selection:text-slate-900">
      {/* Navigation */}
      <Navbar
        onOpenLogin={handleLoginClick}
        userPhone={userPhone}
        onLogout={handleLogout}
      />

      {/* Main Content */}
      <main>
        {/* 1. Hero */}
        <Hero
          onStartProject={handleStartProject}
          onExploreWork={handleExploreWork}
        />

        {/* 2. AI planner and brand promise sections inspired by the live WebNova site */}
        <AIPlannerSection />
        <BrandPromiseSection />

        {/* Existing Why WebNova section */}
        <WhyWebNovaAndAI onExploreAITools={handleExploreAITools} />

        {/* 3. AI Command Center */}
        <AICommandCenter />

        {/* 4. Connected Ecosystem */}
        <ConnectedEcosystem />

        {/* 5. Modern Experience Lab */}
        <ExperienceLab />

        {/* 6. Associate Ecosystem */}
        <AssociateEcosystem />

        {/* 8. Value Props */}
        <ValueProps />

        {/* 9. About WebNova & Interactive Device Mockup */}
        <AboutWebNova />

        {/* 10. Our Services */}
        <ServicesSection />

        {/* Search-friendly growth content, industry use cases, and conversion paths */}
        <SEOContentSection />

        {/* 12. Our Process */}
        <ProcessSection />

        {/* Full-width consultation booking section */}
        <ScheduleCall />

        {/* 13. FAQ */}
        <FaqSection />

        {/* 14. Client Testimonials */}
        <TestimonialsSection />

        {/* Google Reviews and customer feedback */}
        <GoogleReviewsSection />

        {/* 16. Contact Section */}
        <ContactSection onStartProject={handleStartProject} />
      </main>

      {/* Footer */}
      <Footer />

      {/* First-visit service enquiry prompt; submissions feed the Form Inbox capture. */}
      <ServiceRequestPrompt />

      {/* Floating animated chatbot and support-ticket form */}
      <SupportHub />

      {/* Logged-In User Dashboard Modal */}
      {userPhone && (
        <UserPortalModal
          isOpen={isPortalOpen}
          onClose={() => setIsPortalOpen(false)}
          phone={userPhone}
          onLogout={handleLogout}
        />
      )}
    </div>
  );
}


export default function App() {
  const pathname = typeof window !== 'undefined' ? window.location.pathname.replace(/\/$/, '') || '/' : '/';
  let page: React.ReactNode;
  if (pathname === '/privacy-policy') page = <LegalPage kind="privacy" />;
  else if (pathname === '/terms-and-conditions') page = <LegalPage kind="terms" />;
  else if (pathname === '/freelancer') page = <FreelancerComingSoon />;
  else if (pathname === '/admin') page = <FirebaseAuthRoute expectedRole="admin" />;
  else if (pathname === '/blog') page = <BlogPage />;
  else if (pathname === '/verify-certificate') page = <CertificateVerificationPage />;
  else if (pathname === '/portal' || pathname === '/user') page = <FirebaseAuthRoute expectedRole="client" />;
  else if (!['/', '/index.html'].includes(pathname)) page = <NotFoundPage />;
  else page = <HomePage />;
  return <><FormSecurityAndCapture />{page}</>;
}
