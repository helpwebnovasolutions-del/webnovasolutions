import { initializeApp, getApps, type FirebaseApp } from 'firebase/app';
import { getAuth, type Auth } from 'firebase/auth';
import { getFirestore, type Firestore } from 'firebase/firestore';

/**
 * WebNova Solutions Firebase project: authenticationwebnovasolutions.
 * Environment variables can override these defaults for another deployment.
 * Firebase web config is public by design; security belongs in Auth + Firestore Rules.
 */
const firebaseConfig = {
  apiKey: (import.meta.env.VITE_FIREBASE_API_KEY as string | undefined) || 'AIzaSyAwcNhI9CrOtDEevIji9ReAglkPuNf-dkQ',
  authDomain: (import.meta.env.VITE_FIREBASE_AUTH_DOMAIN as string | undefined) || 'authenticationwebnovasolutions.firebaseapp.com',
  databaseURL: (import.meta.env.VITE_FIREBASE_DATABASE_URL as string | undefined) || '',
  projectId: (import.meta.env.VITE_FIREBASE_PROJECT_ID as string | undefined) || 'authenticationwebnovasolutions',
  storageBucket: (import.meta.env.VITE_FIREBASE_STORAGE_BUCKET as string | undefined) || 'authenticationwebnovasolutions.firebasestorage.app',
  messagingSenderId: (import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID as string | undefined) || '257722078505',
  appId: (import.meta.env.VITE_FIREBASE_APP_ID as string | undefined) || '1:257722078505:web:47d66007711fc4101d9338',
  measurementId: (import.meta.env.VITE_FIREBASE_MEASUREMENT_ID as string | undefined) || 'G-RYECWWP928',
};

const requiredConfig = [
  firebaseConfig.apiKey,
  firebaseConfig.authDomain,
  firebaseConfig.projectId,
  firebaseConfig.appId,
];
export const firebaseConfigured = requiredConfig.every(
  (value) => typeof value === 'string' && value.trim().length > 0 &&
    !value.includes('YOUR_') && !value.includes('MY_'),
);

let app: FirebaseApp | null = null;
if (firebaseConfigured) {
  app = getApps().length ? getApps()[0] : initializeApp(firebaseConfig);
}

export const firebaseApp = app;
export const auth: Auth | null = app ? getAuth(app) : null;
export const db: Firestore | null = app ? getFirestore(app) : null;
